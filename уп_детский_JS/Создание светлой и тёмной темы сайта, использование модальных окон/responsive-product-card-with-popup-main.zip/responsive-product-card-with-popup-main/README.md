# Responsive Product Card With Popup
## [Watch it on youtube](https://youtu.be/pMxZc8SarIw)
### Responsive Product Card With Popup

- Responsive Product Card With Popup Using HTML CSS And JavaScript
- It contains beautiful computer images on the card.
- We close the modal by clicking on the background and the close icon.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
